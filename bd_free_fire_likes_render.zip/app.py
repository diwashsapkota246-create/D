import os
import re
import sqlite3
from datetime import datetime, timezone
from flask import Flask, render_template, request, redirect, url_for, flash, g

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-production")
DATABASE = os.environ.get("DATABASE_PATH", "likes.db")

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_error):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS players (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uid TEXT NOT NULL UNIQUE,
            nickname TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
        )
    """)
    db.commit()

@app.before_request
def setup():
    init_db()

@app.get("/")
def index():
    players = get_db().execute(
        "SELECT uid, nickname, created_at FROM players ORDER BY id DESC LIMIT 100"
    ).fetchall()
    today = datetime.now(timezone.utc).date().isoformat()
    today_count = get_db().execute(
        "SELECT COUNT(*) FROM players WHERE substr(created_at, 1, 10) = ?", (today,)
    ).fetchone()[0]
    return render_template("index.html", players=players, today_count=today_count)

@app.post("/submit")
def submit():
    uid = request.form.get("uid", "").strip()
    nickname = request.form.get("nickname", "").strip()[:24]
    confirmed = request.form.get("bd_server") == "yes"

    if not re.fullmatch(r"[0-9]{5,20}", uid):
        flash("Please enter a valid numeric Free Fire UID (5–20 digits).", "error")
        return redirect(url_for("index"))
    if not confirmed:
        flash("Please confirm that your account is on the Bangladesh (BD) server.", "error")
        return redirect(url_for("index"))

    try:
        get_db().execute(
            "INSERT INTO players (uid, nickname, created_at) VALUES (?, ?, ?)",
            (uid, nickname, datetime.now(timezone.utc).isoformat())
        )
        get_db().commit()
        flash("Your UID has been added to the community list!", "success")
    except sqlite3.IntegrityError:
        flash("That UID is already on the community list.", "error")
    return redirect(url_for("index"))

@app.post("/delete")
def delete():
    # This intentionally does not expose public deletion. Add authenticated admin
    # controls before enabling deletion or moderation in a public deployment.
    flash("For privacy or removal requests, contact the site administrator.", "info")
    return redirect(url_for("index"))

@app.get("/health")
def health():
    return {"status": "ok"}

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
