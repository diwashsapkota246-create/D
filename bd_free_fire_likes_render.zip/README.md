# BD Free Fire Likes

A Flask-based community UID board for Bangladesh-server Free Fire players. Players voluntarily share their numeric UID; other visitors can copy it and choose to support them manually in-game.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000.

## Deploy to Render
1. Create a GitHub account and a new repository named `bd-free-fire-likes`.
2. Upload the contents of this folder to the repository (not the ZIP file itself).
3. In Render, choose **New + → Blueprint** and connect that GitHub repository.
4. Render reads `render.yaml`; review the settings and deploy.
5. Your public URL will look like `https://bd-free-fire-likes.onrender.com` (the exact URL is assigned by Render).

## Important deployment/data notes
- This starter uses SQLite. Render's ordinary service filesystem may be ephemeral, so entries can be lost when the service restarts or redeploys. For persistent community submissions, connect a managed PostgreSQL database and update the app to use it before promoting the site.
- The BD server checkbox is self-declared. UID format alone cannot reliably prove a player's server.
- This site does not connect to Garena, automate likes, or promise in-game likes. Visitors must choose to support profiles manually.
- Before a public launch, add spam protection, moderation, an authenticated admin removal workflow, a privacy notice, and persistent database storage. Do not collect passwords or OTPs.
- Set a strong `SECRET_KEY` in Render environment variables if you deploy manually. The Blueprint generates one automatically.
